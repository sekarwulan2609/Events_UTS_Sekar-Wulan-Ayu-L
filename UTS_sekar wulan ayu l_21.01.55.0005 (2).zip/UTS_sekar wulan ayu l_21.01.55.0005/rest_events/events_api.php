<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];
$request = [];

if (isset($_SERVER['PATH_INFO'])) {
    $request = explode('/', trim($_SERVER['PATH_INFO'],'/'));
}

function getConnection() {
    $host = 'localhost';
    $db   = 'events';
    $user = 'root';
    $pass = ''; // Ganti dengan password MySQL Anda jika ada
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try {
        return new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
}

function response($status, $data = NULL) {
    header("HTTP/1.1 " . $status);
    if ($data) {
        echo json_encode($data);
    }
    exit();
}
function validateevents($name, $date, $location, $price) {
    $errors = [];
    if (empty($name)) {
        $errors[] = "name is required";
    }
    if (empty($date)) {
        $errors[] = "date is required";
    }
    if (empty($location)) {
        $errors[] = "location is required";
    }
    if (empty($price)) {
        $errors[] = "price is required";
    }
    return $errors;
}
$db = getConnection();

switch ($method) {
    case 'GET':
        if (!empty($request) && isset($request[0])) {
            if ($request[0] === 'search') {
                // 5.1 Search functionality
                $searchTerm = $_GET['term'] ?? '';
                $stmt = $db->prepare("SELECT * FROM events WHERE name LIKE ? OR location LIKE ?");
                $searchTerm = "%$searchTerm%";
                $stmt->execute([$searchTerm, $searchTerm]);
                $events = $stmt->fetchAll();
                response(200, $events);
            } else {
                // Get specific events
                $id = $request[0];
                $stmt = $db->prepare("SELECT * FROM events WHERE id = ?");
                $stmt->execute([$id]);
                $events = $stmt->fetch();
                if ($events) {
                    response(200, $events);
                } else {
                    response(404, ["message" => "events not found"]);
                }
            }
        } else {
            // 5.2 Pagination
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
            $offset = ($page - 1) * $limit;

            $stmt = $db->prepare("SELECT * FROM events LIMIT ? OFFSET ?");
            $stmt->bindValue(1, $limit, PDO::PARAM_INT);
            $stmt->bindValue(2, $offset, PDO::PARAM_INT);
            $stmt->execute();
            $events = $stmt->fetchAll();

            $totalStmt = $db->query("SELECT COUNT(*) FROM events");
            $total = $totalStmt->fetchColumn();

            response(200, [
                'events' => $events,
                'total' => $total,
                'page' => $page,
                'limit' => $limit
            ]);
        }
        break;
    
    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        $errors = validateevents($data->name ?? '', $data->date ?? '', $data->location ?? '', $data->price ?? '' );
        if (!empty($errors)) {
            response(400, ["errors" => $errors]);
        }
        $sql = "INSERT INTO events (name, date, location, price) VALUES (?, ?, ?, ?)";
        $stmt = $db->prepare($sql);
        if ($stmt->execute([$data->name, $data->date, $data->location, $data->price])) {
            response(201, ["message" => "events created", "id" => $db->lastInsertId()]);
        } else {
            response(500, ["message" => "Failed to create events"]);
        }
        break;
    
    case 'PUT':
        if (empty($request) || !isset($request[0])) {
            response(400, ["message" => "events ID is required"]);
        }
        $id = $request[0];
        $data = json_decode(file_get_contents("php://input"));
        $errors = validateevents($data->name ?? '', $data->date ?? '', $data->location ?? '', $data->price ?? '');
        if (!empty($errors)) {
            response(400, ["errors" => $errors]);
        }
        $sql = "UPDATE events SET name = ?, date = ?, location = ?, price = ? WHERE id =?";
        $stmt = $db->prepare($sql);
        if ($stmt->execute([$data->name, $data->date, $data->location, $data->price, $id])) {
            response(200, ["message" => "events updated"]);
        } else {
            response(500, ["message" => "Failed to update events"]);
        }
        break;
    
    case 'DELETE':
        if (empty($request) || !isset($request[0])) {
            response(400, ["message" => "events ID is required"]);
        }
        $id = $request[0];
        $sql = "DELETE FROM events WHERE id = ?";
        $stmt = $db->prepare($sql);
        if ($stmt->execute([$id])) {
            response(200, ["message" => "events deleted"]);
        } else {
            response(500, ["message" => "Failed to delete events"]);
        }
        break;
    
    default:
        response(405, ["message" => "Method not allowed"]);
        break;
}
?>